import copy
from xml.dom import ValidationErr
from .sns_publisher import SnsPublisher
from typing import List, Callable

class StreamMediator():
    
    _sns_publishers: dict = {}
    _subscribers: dict = {}
    
    def __init__(self) -> None:
        pass
    
    def register_topic(self, topic, iam=None, options: dict=None):
        publisher = SnsPublisher(topic, iam=iam, options=options)
        self._sns_publishers[topic] = publisher
        self._subscribers['topic'] = [publisher.publish]
    
    def publish(self, stream, message):
        if (not stream in self._subscribers):
            raise ValueError(f"Stream {stream} doesn't exist")
        subscribers = copy.deepcopy(self._subscribers[stream])
        for publish in subscribers:
            publish(message)
    
    def subscribe(self, stream_name, publisher):
        if (stream_name in self._subscribers):
            self._subscribers[stream_name].append(publisher)
        else:
            self._subscribers[stream_name] = [publisher]
    
    def merge_topics(self, stream_name, topic_names: List):
        for name in topic_names:
            if (name in self._sns_publishers):
                publisher = self._sns_publishers[name]
                self.subscribe(stream_name, publisher.publish)
            else:
                raise ValidationErr(f"The topic {name} hasn't been registered. Please register the stream first.")
            