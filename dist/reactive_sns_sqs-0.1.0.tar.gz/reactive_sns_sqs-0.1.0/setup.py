# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['reactive_sns_sqs', 'reactive_sns_sqs.models']

package_data = \
{'': ['*']}

install_requires = \
['Rx>=3.2.0,<4.0.0',
 'boto3>=1.20.35,<2.0.0',
 'botocore>=1.23.35,<2.0.0',
 'pydantic>=1.9.0,<2.0.0']

setup_kwargs = {
    'name': 'reactive-sns-sqs',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'jonbran',
    'author_email': 'jon@jonbrandon.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
